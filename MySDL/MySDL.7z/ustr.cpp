#include <stdlib.h>
#include "device.h"