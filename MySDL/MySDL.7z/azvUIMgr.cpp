#include "azvUIMgr.h"





azvUIMgr::azvUIMgr(azEngine * e):azView(e)
{
}

azvUIMgr::~azvUIMgr()
{
}
