#pragma once
#include "azView.h"
class azvUIMgr :
	public azView
{
public:
	azvUIMgr(azEngine*e);
	
	virtual ~azvUIMgr();
};

