#include "MyMusic.h"
#include <fstream>
#include <io.h>
#include "tinyxml2.h"

static const char*music_suffix[] = { "mp3","wav","fla","aac",nullptr };

void add_info_str(std::string&s, const std::string&name, const char*val)
{
	if (val)
	{
		s += '\n';
		s += name;
		s += ':';
		s += val;
	}
}

int is_suffix_file(const char*name,const char*suffix[])
{
	const char*p = name;
	const char*dot = nullptr;
	while (*p)
	{
		if (*p == '.')
			dot = p+1;
		p++;
	}
	if (dot == nullptr)
		return 0;

	for (int i=0;suffix[i];i++)
	{
		if (!_stricmp(dot, suffix[i]))
			return i+1;
	}
	return 0;
}


void MyMusic::init()
{
	azApp::init();
	play_mode = 0;
	nowsongid = -1;
	setlocale(LC_ALL, "");

	engine->set_title("azMusic");
	engine->BlendMode(SDL_BLENDMODE_BLEND);

	media.initAudio();

	init_songs();

	music_ico = engine->LoadTexture("music_ico.png");
	music_ico->setSize(24, 24);

	mainui();

}

void MyMusic::destroy()
{
	media.deinitAudio();
	azApp::destroy();
}

void MyMusic::onEvent(SDL_Event & event)
{
	if (event.type == SDL_QUIT)
		endApp();
	else if (event.type == MEDIA_EVENT_FINISH)
	{
		switch (play_mode)
		{
			case 0:
				stopmusic();
				break;
			case 1:
				playmusic(nowsongid);
				break;
			case 2:
				nextmusic();
				break;
		default:
			stopmusic();
			break;
		}
	}
}

void MyMusic::onDraw()
{
	if (mu_length)
	{

		songslide->slider_pos = mu_length ? (double)media.getPosition() / mu_length : 0.0;
		char buf[16];
		TimeSpan ts, ds;
		ts.fromTick(media.getPosition());
		ds.fromTick(mu_length);
		sprintf(buf, "%02d:%02d/%02d:%02d",
			ts.min, ts.sec,
			ds.min, ds.sec);
		timeinfo->text.setText(buf);
	}
}


void MyMusic::mainui()
{
	/*page = new azPage(ui);
	playbtn = new azvButton(page);
	searchbtn = new azvButton(page);
	volslide = new azvSlideBar(page);
	songlist = new azvListbox(page);
	info = new azvLabel(page);
	volinfo= new azvLabel(page);
	songslide = new azvSongSlide(page);
	timeinfo = new azvLabel(page);
	circle_mode = new azvChoiceButton(page);


	page->setSize(engine->get_winrect().w, engine->get_winrect().h);
	page->back.tex = engine->LoadTexture("test.bmp");
	
	playbtn->setPos(96, page->area.h - 48);
	playbtn->setSize(96, 36);
	playbtn->text.setText(L"ֹͣ");
	playbtn->onClick = [this](azvButtonBase&) {this->stopmusic(); };

	searchbtn->setPos(96+128, page->area.h - 48);
	searchbtn->setSize(128, 36);
	searchbtn->text.setText(L"��������");
	searchbtn->onClick = [this](azvButtonBase&) {
		tinyxml2::XMLDocument doc;
		tinyxml2::XMLElement *eles;
		tinyxml2::XMLElement *p;
		doc.LoadFile(SONG_FILE_NAME);
		eles=doc.FirstChildElement("SearchSong");
		if (eles)
		{
			p = eles->FirstChildElement("Path");
			while (p)
			{
				const char*s = p->Attribute("path");
				if(s)
					this->search_songs(s);
				p = p->NextSiblingElement("Path");
			}
		}
	
	};

	songlist->setPos(0, 32);
	songlist->setSize(page->area.w / 2, page->area.h - 128);
	songlist->OnItemClick = [this](azvList&, int item) {if (item >= 0)this->playmusic(item); };
	songlist->back.color = COLOR(32, 32, 188, 64);
	setuplist();

	info->setPos(page->area.w / 2 + 32, 32);
	info->setSize(page->area.w / 2 - 64, 192);
	info->back.color = COLOR(63, 63, 0, 32);
	info->text.setText(L"δ��������");

	volslide->setPos(page->area.w/2+64,page->area.h-96);
	volslide->setSize(page->area.w/2-96,24);
	volslide->line_color = COLOR(128, 128, 128, 255);
	volslide->slider_pos = 1.0;
	volslide->onSliderMove = [this](double pos) {
		std::wstringstream ss;
		ss << L"������" << (int)(100 * pos)<<'%';
		volinfo->text.setText(ss.str());
		media.setVolume((int)(pos * 128));
	};

	volinfo->setPos(page->area.w / 2 + 32, page->area.h - 64);
	volinfo->setSize(128, 24);
	volinfo->text.setColor(COLOR_BLACK);
	volinfo->text.setText(L"������100%");

	timeinfo->setPos(page->area.w / 2 + 64, page->area.h - 160);
	timeinfo->setSize(page->area.w / 2 - 96, 24);
	timeinfo->text.setColor(COLOR_BLACK);

	songslide->setPos(page->area.w / 2 + 64, page->area.h - 128);
	songslide->setSize(page->area.w / 2 - 96, 24);

	circle_mode->setPos(page->area.w / 2 + 160, page->area.h - 64);
	circle_mode->setSize(128, 32);

	circle_mode->addItem(L"��������");
	circle_mode->addItem(L"����ѭ��");
	circle_mode->addItem(L"�б�ѭ��");
	circle_mode->setSelect(0);
	circle_mode->onSelect= [this](int id) {
		if (id >= 0 && id < 3)
		{
			play_mode = id;
		}
	};
*/
	azWindow *awin = new azWindow(ui);
	azBoxLayout*layout = new azBoxLayout(awin);
	azvLabel*lab1 = new azvLabel(layout);
	azvButton*btn1 = new azvButton(layout);
	azvImage*img1 = new azvImage(layout);
	awin->setSize(800, 600);
	awin->setPos(100, 50);
	awin->title_back.color = COLOR_DARK;

	layout->setSize(768, 512);

	lab1->setSize(128, 32);
	lab1->text.setText(L"���ѽ��");
	btn1->setSize(160, 54);
	btn1->text.setText(L"����һ����");
	btn1->onClick = [](azvButtonBase&) {DBGLOG("btn1 clicked!"); };
	img1->setImage(engine->LoadTexture("013.jpg"));
	img1->setScale(0.3);
	layout->padding = 10;
	layout->spacing = 16;
	layout->Align = ALIGN_LEFT|ALIGN_TOP;
	layout->Dirction = LAYOUT_VERTICAL;
	layout->updateLayout();
}

int MyMusic::playmusic(int i)
{
	stopmusic();
	if (i < 0 || (size_t)i >= songs.size())
	{
		return -1;
	}

	nowsongid = i;
	media.OpenFile(songs[nowsongid].c_str());
	if (media.isReady())
	{
		std::string infotxt;
		std::wstring infotxtw;
		media.play();
		mu_start_tick = engine->GetTick();
		mu_length = media.GetDuration();

		songlist->SetItemColor(nowsongid, COLOR_BLUE);
		DBGLOG("LoadMusic %s", songs[nowsongid].c_str());

		infotxt = songs[nowsongid];
		char buf[16];
		TimeSpan ts;
		ts.fromTick(media.GetDuration());
		sprintf(buf, "%02d:%02d:%02d", ts.hour, ts.min, ts.sec);
		add_info_str(infotxt, "Duration", buf);
		add_info_str(infotxt, "Artists", media.GetMetaData("artist"));
		add_info_str(infotxt, "Album", media.GetMetaData("album"));

		u8stows(infotxtw, infotxt.c_str());

		info->text.setText(L"���ڲ��ţ�"+ infotxtw);
		songslide->slider_pos = 0.0;
	}
	else
	{
		info->text.setText(SDL_GetError());
		DBGLOG("MediaStream Error %s", SDL_GetError());
		return -1;
	}
	return 0;
}

int MyMusic::nextmusic()
{
	for (int i = nowsongid+1; ; i++)
	{
		if (i >= songs.size())
			i = 0;
		if (playmusic(i) == 0)
			return 0;
		if (i == nowsongid)
			break;
	}
	return -1;
}


int MyMusic::stopmusic()
{
	if (nowsongid>=0)
	{
		songlist->SetItemColor(nowsongid, COLOR_WHITE);
		songlist->unSelect();
		info->text.setText(L"δ��������");
		timeinfo->text.setText(L"");

		media.CloseFile();
		mu_length = mu_start_tick = 0;
		songslide->slider_pos = 0.0;
		timeinfo->text.setText(L"");
		nowsongid = -1;
	}
	return 0;
}

void MyMusic::load_config()
{
}

void MyMusic::init_songs()
{
	tinyxml2::XMLDocument doc;
	tinyxml2::XMLElement*song_ele;
	tinyxml2::XMLElement*song_path;
	doc.LoadFile(SONG_FILE_NAME);
	song_ele = doc.FirstChildElement("Songs");
	if (!song_ele)
		return;
	song_path = song_ele->FirstChildElement("Path");
	while (song_path)
	{
		const char*s = song_path->Attribute("path");
		if (s)
			songs.push_back(s);
		song_path = song_path->NextSiblingElement("Path");
	}

}

void MyMusic::save_songs()
{
	tinyxml2::XMLDocument doc;
	tinyxml2::XMLElement*song_ele;
	doc.LoadFile(SONG_FILE_NAME);

	song_ele=doc.FirstChildElement("Songs");
	if (song_ele)
		song_ele->DeleteChildren();
	else
	{
		song_ele = doc.NewElement("Songs");
		doc.LinkEndChild(song_ele);
	}

	for (auto&s : songs)
	{
		tinyxml2::XMLElement*song_name = doc.NewElement("Path");
		song_name->SetAttribute("path", s.c_str());
		song_ele->LinkEndChild(song_name);
	}
	doc.SaveFile(SONG_FILE_NAME);
}

void MyMusic::search_songs(const std::string & path)
{
	std::string serpath;
	bool songadded = false;

	u8stocs(serpath, path.c_str());
	serpath+=DIR_SEPS"*.*";
	_finddata_t FileInfo;
	long handle = _findfirst(serpath.c_str(), &FileInfo);
	if (handle == -1)
		return;
	do {
			std::string s(path);
			s += DIR_SEP;
			s += FileInfo.name;
			if (is_suffix_file(s.c_str(), music_suffix))
			{
				std::wstring ws;
				size_t beg;
				cstows(ws, s.c_str());
				wstou8s(s, ws.c_str());
				
				beg = ws.find_last_of(DIR_SEP);
				if (beg == std::string::npos)
					add_song(s,ws);
				else
					add_song(s, ws.substr(beg+1));

				songadded = true;
			}
	} while (_findnext(handle, &FileInfo) == 0);
	if (songadded)
		save_songs();
	_findclose(handle);
}

void MyMusic::show_dir_choose(std::string & path)
{

}

void MyMusic::add_song(const std::string & path,const std::wstring&name)
{
	auto it = std::find(songs.begin(), songs.end(), path);
	if (it == songs.end())
	{
		songs.push_back(path);
		songlist->InsertText(name);
	}
}


// ͨ�� UIPage �̳�

void MainPage::setup()
{
}

void MainPage::destroy()
{
}


void MyMusic::setuplist()
{
	for (auto&s : songs)
	{
		size_t beg;
		beg= s.find_last_of(DIR_SEP);

		std::wstring ws;
		if (beg ==std::string::npos)beg = 0;else beg++;
		u8stows(ws, s.substr(beg).c_str());

		int i=songlist->InsertText(ws);
		songlist->GetItemIcon(i) = music_ico;

		std::wstringstream ss;
		ss << L"����" << songs.size() << L"�׸���";
		songlist->title.setText(ss.str());
	}
}


void azApp::run()
{
	running = 1;
	init();

	eventloop();

	destroy();
}

void azApp::endApp()
{
	running = 0;
}

void azApp::init()
{
	engine = new azEngine();
	engine->init();

	ui = new azPage(engine);
	ui->setPos(0, 0);
	ui->setSize(engine->area().w, engine->area().h);
}

void azApp::destroy()
{
	engine->deinit();
	delete engine;
	delete ui;
}

void azApp::onDraw()
{
}

void azApp::onEvent(SDL_Event & event)
{
}

void azApp::onTick()
{
}

void azApp::eventloop()
{
	SDL_Event event;
	while (running)
	{
		engine->RenderClear();
		onDraw();
		ui->draw();
		engine->RenderFresh();
		while (SDL_PollEvent(&event))
		{
			ui->onEvent(event);
			onEvent(event);
		}
	engine->Tick();
		onTick();
	}
}
