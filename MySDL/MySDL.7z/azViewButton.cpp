#include "azViewButton.h"



int azViewButton::setText(std::string & str)
{
	return 0;
}

int azViewButton::setBackground(SDL_Color color, int flag)
{
	return 0;
}

int azViewButton::setForeground(SDL_Color color, int flag)
{
	return 0;
}

int azViewButton::setBackground(azTexture & tex, int flag)
{
	return 0;
}


azViewButton::~azViewButton()
{
}
