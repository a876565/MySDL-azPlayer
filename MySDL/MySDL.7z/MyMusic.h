#pragma once
#include "azEngine.h"
#include "AudioStream.h"
#include "azView.h"
#include "azText.h"

#include "azvLabel.h"
#include "azvImage.h"
#include "azvButton.h"
#include "azvListbox.h"
#include "azvSlideBar.h"
#include "azvUIMgr.h"
#include "azChoicePage.h"
#include "azvChoiceButton.h"
#include "azLayout.h"
#include "azWindow.h"

#include <string>
#include <stdio.h>
#include <sstream>

class azApp {
	int running;
protected:
	azPage * ui;
	azEngine * engine;
public:

	virtual void run();
	void endApp();
	//����/�Ƴ�page
	void addPage(azPage*p);
	void delPage(azPage*);
	//��ʼ����
	//��ʼ��
	virtual void init();
	//���ٲ��ͷ���Դ
	virtual void destroy();
	//����ͼ��
	virtual void onDraw();
	//�����¼�
	virtual void onEvent(SDL_Event&event);
	//�¼�֮���ʱ��ص�
	virtual void onTick();


	void eventloop();
};
class UIPage
{
public:
	virtual void setup() = 0;
	virtual void destroy() = 0;
};
class MainPage :public UIPage
{
	azPage* root;
	azvListbox*songs;
	// ͨ�� UIPage �̳�
	virtual void setup() override;
	virtual void destroy() override;
};
struct MusicInfo {
	std::string name;
	std::string path;
};
class MyMusic :public azApp {

	azPage* page;
	azvButton*playbtn ;
	azvButton*searchbtn;
	azvLabel*info;
	azvListbox*songlist;
	azvSlideBar*volslide;
	azvLabel*volinfo;
	azvSongSlide*songslide;
	azvLabel*timeinfo;
	azvChoiceButton*circle_mode;

	azTexture music_ico;

	int nowsongid;
	/*0=��������
	1=����ѭ��
	2=�б�ѭ��
	3=�б����*/
	int play_mode;

	/*0=ֹͣ
	1=����
	*/
	int play_state;

	MediaStream media;
	int mu_start_tick, mu_length;

	std::vector<std::string>songs;
public:
	void init();
	void destroy();
	void onEvent(SDL_Event&event) override;
	void onDraw() override;

	void mainui();
	int playmusic(int i);
	int nextmusic();
	int stopmusic();

	void load_config();
	
	void init_songs();
	void save_songs();
	void search_songs(const std::string&path);
	void show_dir_choose(std::string&path);
	void add_song(const std::string & path, const std::wstring & name);

	void setuplist();
};