#include "azGraph.h"

azGraph::~azGraph()
{
}
